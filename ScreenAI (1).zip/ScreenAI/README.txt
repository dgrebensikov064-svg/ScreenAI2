1. Скачай rus.traineddata и eng.traineddata (tessdata_fast) с
   https://github.com/tesseract-ocr/tessdata_fast
   и положи в app/src/main/assets/tessdata/
2. Открой папку ScreenAI в Android Studio, дождись синхронизации Gradle.
3. Запусти на телефоне (Android 10+).
4. В приложении вставь DeepSeek API key -> "Запустить" -> дай разрешения.
5. Появится кнопка "AI" поверх экрана: нажми, напиши или скажи запрос.
